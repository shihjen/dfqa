def test_import_package():
    import dfqa
